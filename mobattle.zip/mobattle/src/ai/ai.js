/*
CONTRACT — src/ai/ai.js (AI Layer)
1. does:        Produces an intent object for P2 (the RIVAL) by reading distance/hp/timers heuristically.
2. owns:        The exported `intent` object — same shape as input.intent, but computer-generated.
3. needs:       core/state.js S.p1/p2 positions and hp to decide behavior.
4. inputs:      Distance to opponent, own cooldowns, own/opponent hp.
5. outputs:     intent{moveX,punch,kick,block,special}, refreshed every AI tick.
6. connectsTo:  movement/movement.js (reads moveX), combat/combat.js (reads action flags).
7. helps:       Makes single-player fights possible against the RIVAL without a second human,
                 which matters even more now that there's only one fighter definition to draw from.
8. returns:     intent object, step(dt) — named exports.
9. starts:      step(dt) called once per frame from the fight loop.
10. finishes:   Each decision finishes within its own tick; re-decided next tick.
*/

import { S } from '../core/state.js';

export const intent = { moveX: 0, punch: false, kick: false, block: false, special: false };
let decisionTimer = 0;

export function step(dt) {
  const { p1, p2 } = S;
  if (!p1 || !p2 || S.matchOver) { resetIntent(); return; }

  decisionTimer -= dt;
  const dist = p1.x - p2.x;
  const absDist = Math.abs(dist);

  if (decisionTimer <= 0) {
    decisionTimer = 0.12 + Math.random() * 0.18;
    resetIntent();

    if ((p1.state === 'punch' || p1.state === 'kick') && absDist < 60 && Math.random() < 0.45) {
      intent.block = true;
      return;
    }

    if (absDist > 60) {
      intent.moveX = dist > 0 ? -1 : 1;
    } else if (absDist < 30) {
      if (Math.random() < 0.3) intent.moveX = dist > 0 ? 1 : -1;
    }

    const canSpecial = p2.cooldownSpecial <= 0 && absDist < 70 && Math.random() < 0.22;
    if (canSpecial) { intent.special = true; return; }

    if (absDist < 55 && Math.random() < 0.5) {
      if (Math.random() < 0.5) intent.punch = true; else intent.kick = true;
    }
  }
}

function resetIntent() {
  intent.moveX = 0; intent.punch = false; intent.kick = false; intent.block = false; intent.special = false;
}

export const contract = {
  does: "Generates the RIVAL's behavior heuristically so single-player fights work.",
  owns: "The `intent` export.",
  needs: "state.S.p1/p2 (position, state, hp, cooldowns).",
  inputs: "Distance to opponent, own cooldown, opponent's current action state.",
  outputs: "intent, refreshed every 0.12-0.3s decision tick.",
  connectsTo: "movement/movement.js, combat/combat.js.",
  helps: "Enables solo play against the rival without a second device/player.",
  returns: "intent object, step(dt).",
  starts: "step(dt) each frame from the fight loop.",
  finishes: "Each decision resolves within its own tick window."
};
