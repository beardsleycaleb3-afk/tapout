/*
CONTRACT — src/audio/audio.js (Audio Layer)
1. does:        Synthesizes short SFX tones for hits/blocks/specials via oscillators.
2. owns:        One shared AudioContext and its unlock state.
3. needs:       A user gesture to unlock AudioContext (Chrome autoplay policy).
4. inputs:      sfx(name) calls from combat/combat.js and scenes/scenes.js.
5. outputs:     Short synthesized tones played through the device speaker.
6. connectsTo:  combat/combat.js (hit/block/special/punch/kick cues), scenes/scenes.js (menu confirm).
7. helps:       Adds audio feedback with zero asset weight — stays offline/PWA-safe.
8. returns:     Nothing — fire-and-forget playback. unlock() and sfx() are named exports.
9. starts:      unlock() on first tap; sfx() starts a tone per call.
10. finishes:   Each tone finishes itself via its own GainNode envelope/stop().
*/

let ctx = null;

export function unlock() {
  if (!ctx) {
    try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
  }
}

function tone(freq, dur, type, gainPeak) {
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type || 'square';
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(0, ctx.currentTime);
  gain.gain.linearRampToValueAtTime(gainPeak || 0.15, ctx.currentTime + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
  osc.connect(gain).connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + dur);
}

export function sfx(name) {
  if (!ctx) return;
  switch (name) {
    case 'punch': tone(180, 0.08, 'square', 0.18); break;
    case 'kick': tone(120, 0.12, 'square', 0.2); break;
    case 'block': tone(400, 0.06, 'triangle', 0.12); break;
    case 'hit': tone(90, 0.15, 'sawtooth', 0.22); break;
    case 'special': tone(600, 0.3, 'sawtooth', 0.2); setTimeout(() => tone(300, 0.2, 'square', 0.15), 80); break;
    case 'finisher':
      tone(700, 0.15, 'sawtooth', 0.25);
      setTimeout(() => tone(500, 0.15, 'sawtooth', 0.25), 90);
      setTimeout(() => tone(900, 0.35, 'square', 0.3), 180);
      break;
    case 'ko': tone(80, 0.5, 'sawtooth', 0.25); break;
    case 'confirm': tone(500, 0.08, 'square', 0.15); break;
  }
}

export const contract = {
  does: "Synthesizes SFX with WebAudio oscillators — no audio files needed.",
  owns: "The shared AudioContext.",
  needs: "A user gesture to unlock playback.",
  inputs: "sfx(name) calls.",
  outputs: "Short tones through the speaker.",
  connectsTo: "combat/combat.js, scenes/scenes.js.",
  helps: "Audio feedback with zero bundle weight, stays offline-safe.",
  returns: "Nothing (fire-and-forget). unlock(), sfx() functions.",
  starts: "unlock() on first tap; sfx() per call.",
  finishes: "Each tone self-terminates via its gain envelope."
};
