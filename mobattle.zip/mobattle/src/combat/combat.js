/*
CONTRACT — src/combat/combat.js (Combat Layer)
1. does:        Turns action intents into attacks, resolves hits/blocks/damage/KOs, and
                 triggers the meter-full finisher (special input while meter>=100 consumes
                 the meter and starts the 'finisher' action instead of the normal special).
2. owns:        state/actionTimer/hitstun/blockstun/hp/comboCount/meter on combatants.
3. needs:       core/state.js S, input.intent (P1 actions), ai.intent (RIVAL actions), audio/fx hooks, scenes.onKO.
4. inputs:      punch/kick/special/block booleans, current x distance between fighters.
5. outputs:     hp changes, hitstop flashes, combo counters, round-over trigger. Combatant.state
                 doubles as the clip-name lookup key render.js uses against spriteAtlas.CLIPS.
6. connectsTo:  core/state.js (mutates), movement (reads x), audio (SFX), fx (visual), scenes (round end).
7. helps:       Is the actual "fight" — the core value proposition of the game.
8. returns:     Nothing directly — mutates S; step(dt) is the named export used by boot.
9. starts:      Once per frame from the fight-scene loop, after movement.step.
10. finishes:   A round finishes here the instant hp hits 0 (delegates to scenes.onKO).
*/

import { S } from '../core/state.js';
import { intent as playerIntent } from '../input/input.js';
import { intent as aiIntent } from '../ai/ai.js';
import * as AUDIO from '../audio/audio.js';
import * as FX from '../fx/fx.js';
import { onKO } from '../scenes/scenes.js';

const RANGE_PUNCH = 46, RANGE_KICK = 54, RANGE_SPECIAL = 70, RANGE_FINISHER = 85;

export function step(dt) {
  const { p1, p2 } = S;
  if (!p1 || !p2 || S.matchOver) return;

  tickTimers(p1, dt); tickTimers(p2, dt);
  resolveActions(p1, p2, playerIntent, dt);
  resolveActions(p2, p1, aiIntent, dt);
}

function tickTimers(c, dt) {
  if (c.actionTimer > 0) { c.actionTimer -= dt; if (c.actionTimer <= 0) { c.actionTimer = 0; if (c.state !== 'ko') c.state = 'idle'; } }
  if (c.hitstun > 0) c.hitstun -= dt;
  if (c.blockstun > 0) c.blockstun -= dt;
  if (c.cooldownSpecial > 0) c.cooldownSpecial -= dt;
  if (c.comboTimer > 0) { c.comboTimer -= dt; if (c.comboTimer <= 0) c.comboCount = 0; }
}

function resolveActions(attacker, defender, intent, dt) {
  if (attacker.hitstun > 0 || attacker.blockstun > 0 || attacker.state === 'ko') return;
  if (attacker.actionTimer > 0) return;

  if (intent.block) { attacker.state = 'block'; return; }

  const dist = Math.abs(attacker.x - defender.x);

  if (intent.special && attacker.meter >= 100) {
    startAction(attacker, 'finisher', 0.7);
    attacker.meter = 0;
    if (dist <= RANGE_FINISHER) applyHit(attacker, defender, attacker.def.finisherDmg, true);
    AUDIO.sfx('finisher');
    FX.bigBanner(attacker.def.finisher, 1100);
    return;
  }
  if (intent.special && attacker.cooldownSpecial <= 0) {
    startAction(attacker, 'special', 0.5);
    attacker.cooldownSpecial = 3.2;
    if (dist <= RANGE_SPECIAL) applyHit(attacker, defender, attacker.def.specialDmg, true);
    AUDIO.sfx('special');
    FX.flashBanner(attacker.def.special);
    return;
  }
  if (intent.punch) {
    startAction(attacker, 'punch', 0.22);
    if (dist <= RANGE_PUNCH) applyHit(attacker, defender, 6 + attacker.def.power * 0.4, false);
    AUDIO.sfx('punch');
    return;
  }
  if (intent.kick) {
    startAction(attacker, 'kick', 0.3);
    if (dist <= RANGE_KICK) applyHit(attacker, defender, 9 + attacker.def.power * 0.6, false);
    AUDIO.sfx('kick');
    return;
  }
  if (attacker.state === 'block') attacker.state = 'idle';
}

function startAction(c, name, duration) {
  c.state = name; c.actionTimer = duration; c.clipFrame = 0; c.clipTimer = 0;
}

function applyHit(attacker, defender, rawDmg, isSpecial) {
  const blocking = defender.state === 'block';
  let dmg = rawDmg * (100 / (100 + defender.def.defense * 3));

  if (blocking) {
    dmg *= 0.15;
    defender.blockstun = 0.18;
    AUDIO.sfx('block');
  } else {
    defender.hitstun = isSpecial ? 0.45 : 0.25;
    defender.state = 'hit'; defender.clipFrame = 0; defender.clipTimer = 0;
    attacker.comboCount = (attacker.comboTimer > 0) ? attacker.comboCount + 1 : 1;
    attacker.comboTimer = 0.9;
    attacker.meter = Math.min(100, attacker.meter + (isSpecial ? 14 : 7));
    if (attacker.comboCount >= 2) FX.comboPop(attacker.comboCount);
    AUDIO.sfx('hit');
    FX.hitSpark(defender.x, defender.y - 60);
    if (navigator.vibrate) navigator.vibrate(isSpecial ? 40 : 18);
  }

  defender.hp = Math.max(0, defender.hp - dmg);

  if (defender.hp <= 0 && defender.state !== 'ko') {
    defender.state = 'ko';
    defender.clipFrame = 0; defender.clipTimer = 0;
    defender.actionTimer = 999;
    onKO(attacker, defender);
  }
}

export const contract = {
  does: "Resolves attacks into damage, blocks, combos, KOs.",
  owns: "Combat-relevant fields on both combatants (hp,state,timers,combo,meter,clip cursor).",
  needs: "state.S, input.intent, ai.intent, audio.sfx, fx hooks, scenes.onKO.",
  inputs: "Per-frame action booleans + inter-fighter distance.",
  outputs: "hp deltas, hitstun/blockstun, combo counters, KO trigger, and the .state string render.js reads as a clip key.",
  connectsTo: "core/state.js, movement/movement.js, audio/audio.js, fx/fx.js, scenes/scenes.js.",
  helps: "Is the core fight simulation the whole game is built around.",
  returns: "Nothing directly (in-place mutation); step(dt) is the export boot uses.",
  starts: "Once per frame after movement.step in the fight loop.",
  finishes: "A round the instant a combatant's hp reaches 0."
};
