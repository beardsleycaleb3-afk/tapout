/*
CONTRACT — src/content/fighter.js (Content Layer — the one fighter)
1. does:        Defines the single playable fighter's stats and identity; derives a RIVAL
                 variant (same sprite, palette-shifted) so single-player fights have an opponent.
2. owns:        FIGHTER object, RIVAL object.
3. needs:       Nothing directly (clip names are strings matched against spriteAtlas.CLIPS
                 by render.js, so this module doesn't need to import the atlas).
4. inputs:      None.
5. outputs:     FIGHTER, RIVAL — named exports.
6. connectsTo:  core/state.js (instantiates combatants from these), combat/combat.js (reads stats),
                 render/render.js (reads tint/id to pick draw treatment).
7. helps:       Single source of truth for the one fighter this repo ships with, per the
                 explicit "1 fighter, not 4" requirement.
8. returns:     FIGHTER (object), RIVAL (object).
9. starts:      Evaluated at module load.
10. finishes:   Never mutated at runtime — read-only content.

WHY A "RIVAL" AND NOT A ROSTER:
This repo intentionally ships ONE fighter. There is no fighter-select screen and no CONTENT
array of multiple entries (see scenes/scenes.js — the old SELECT scene is replaced by a READY
scene). Since a fight still needs two combatants, RIVAL reuses the exact same sprite sheet and
stats as FIGHTER, distinguished only by a canvas hue-rotate tint applied in render.js and a
mirrored default facing. This is the correct way to answer "what does it own?" honestly: this
module owns ONE fighter's identity, not two — RIVAL is a rendering-level palette variant of
that same identity, not a second piece of content.
*/

export const FIGHTER = {
  id: 'boxer',
  name: 'THE BOXER',
  hp: 100,
  speed: 4.0,
  power: 9,
  defense: 7,
  special: 'FLURRY FINISH',
  specialDmg: 22,
  finisher: 'FINAL BELL',
  finisherDmg: 40,
  tint: null // no filter — this is the player's true colors
};

export const RIVAL = {
  ...FIGHTER,
  id: 'boxer-rival',
  name: 'THE RIVAL',
  tint: 'hue-rotate(160deg) saturate(1.3)' // CSS/canvas filter distinguishing the mirror opponent
};

export const contract = {
  does: "Defines the one playable fighter and its palette-swapped rival opponent.",
  owns: "FIGHTER, RIVAL.",
  needs: "Nothing — pure static data.",
  inputs: "None.",
  outputs: "FIGHTER, RIVAL named exports.",
  connectsTo: "core/state.js, combat/combat.js, render/render.js.",
  helps: "Single source of truth for the one fighter, honoring the 1-fighter requirement.",
  returns: "FIGHTER (object), RIVAL (object).",
  starts: "At module evaluation.",
  finishes: "Never mutated after load."
};
