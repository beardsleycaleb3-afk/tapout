/*
CONTRACT — src/content/spriteAtlas.js (Content Layer — sprite data)
1. does:        Slices assets/fighter_sheet.png into addressable 112x112 frames and names
                 groups of frames as animation clips (idle/walk/punch/kick/block/hit/ko/special).
2. owns:        FRAME_W/FRAME_H/COLS/ROWS grid constants, the `image` element, the `CLIPS` map.
3. needs:       assets/fighter_sheet.png to exist at that relative path from index.html.
4. inputs:      None at runtime beyond the image load itself.
5. outputs:     `image` (HTMLImageElement), `frameRect(row,col)`, `CLIPS`, `ready` (Promise).
6. connectsTo:  content/fighter.js (references CLIPS by name), render/render.js (draws frames via image+frameRect).
7. helps:       Turns one unlabeled pixel-art sheet into a semantic animation API the rest of the
                 game can call by clip name instead of raw row/col numbers.
8. returns:     Named exports: image, FRAME_W, FRAME_H, frameRect(), CLIPS, ready.
9. starts:      Begins loading the Image the instant this module is evaluated.
10. finishes:   The `ready` promise resolves once the image has loaded (or rejects on error).

IMPORTANT HONESTY NOTE ON FRAME MAPPING:
The source sheet has no embedded metadata — no frame names, no animation tags. The row/col
indices assigned to each CLIP below are a best-effort VISUAL read of the sheet (grid is 8
columns x 7 rows of 112x112px cells, 54 of the 56 cells populated, last row has 6). This is
not guaranteed to match whatever tool originally exported it. If a clip looks wrong in-game,
open assets/fighter_sheet.png, count cells (0-indexed, left-to-right, top-to-bottom), and
correct the row/col pairs in CLIPS below — that's the only place they're defined.
*/

export const FRAME_W = 112;
export const FRAME_H = 112;
export const COLS = 8;
export const ROWS = 7;

export const image = new Image();
// Note: like sw.js registration, relative asset URLs resolve against the *document*
// base URL (index.html at repo root), not this module's own file location.
image.src = './assets/fighter_sheet.png';

export const ready = new Promise((resolve, reject) => {
  image.onload = () => resolve(image);
  image.onerror = reject;
});

/** Returns the source-rect [sx, sy, sw, sh] for a given row/col cell. */
export function frameRect(row, col) {
  return [col * FRAME_W, row * FRAME_H, FRAME_W, FRAME_H];
}

/**
 * Named animation clips as [row, col] pairs, read visually off the sheet.
 * Each clip is a short frame list; render.js cycles through them on a timer.
 */
export const CLIPS = {
  idle:    [[0, 1], [0, 2], [0, 3], [0, 2]],           // guard-stance sway, row0
  walk:    [[6, 1], [6, 2], [6, 4], [6, 5]],           // side-profile stepping, row6
  punch:   [[1, 3], [5, 2]],                            // reaching jab (row1) into guard jab (row5)
  kick:    [[2, 0]],                                    // single low kick pose, row2
  block:   [[0, 7]],                                    // static side guard, row0
  special: [[3, 0], [1, 3], [5, 3]],                    // wide stance -> reach -> jab flourish
  finisher:[[3, 0], [1, 3], [5, 3], [5, 2], [1, 3]],    // meter-full super: same flourish, held longer
  hit:     [[1, 0]],                                    // stumble/falling pose, row1
  ko:      [[1, 1]]                                     // lying down, row1
};

export const contract = {
  does: "Slices the sprite sheet into frames and exposes named animation clips.",
  owns: "Grid constants, the Image element, and the CLIPS name-to-frames map.",
  needs: "assets/fighter_sheet.png at a path relative to this module.",
  inputs: "None beyond the image's own load event.",
  outputs: "image, frameRect(), CLIPS, ready — all named exports.",
  connectsTo: "content/fighter.js, render/render.js.",
  helps: "Gives the rest of the game a semantic clip API instead of raw pixel math.",
  returns: "image, FRAME_W, FRAME_H, frameRect(), CLIPS, ready.",
  starts: "Image load begins at module evaluation.",
  finishes: "`ready` resolves once the image has loaded."
};
