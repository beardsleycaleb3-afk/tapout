/*
CONTRACT — src/persist/persist.js (Persistence Layer)
1. What does it do? — Saves and loads the player's match record (wins/losses/championships)
                       to localStorage so it survives a page reload or app relaunch.
2. What does it own? — The `record{wins,losses,championships}` object and the
                        'mobattle_record_v1' localStorage key.
3. What does it need? — window.localStorage to exist (guarded — fails silently if unavailable,
                         e.g. private browsing with storage disabled).
4. What does it input? — recordWin()/recordLoss() calls from scenes.js at match-end.
5. What does it output? — The in-memory `record` object, kept in sync with localStorage.
6. What does it connect to? — scenes/scenes.js (calls recordWin/recordLoss, reads record for
                               the title-screen display).
7. What does it help? — Gives the player something that persists across sessions, closing the
                         gap every earlier build in this thread left open: nothing survived a
                         reload before this file existed.
8. What does it return? — `record` (object), load(), recordWin(), recordLoss() — named exports.
                           This is the answer to "what does it return?" at the session boundary
                           that was previously unanswered.
9. What does it start? — load() runs once at module evaluation, before any scene renders.
10. What does it finish? — Nothing — the record only grows; there is no reset path by design
                            (a player's lifetime record shouldn't vanish from a menu tap).
*/

const KEY = 'mobattle_record_v1';

export const record = { wins: 0, losses: 0, championships: 0 };

export function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      record.wins = parsed.wins || 0;
      record.losses = parsed.losses || 0;
      record.championships = parsed.championships || 0;
    }
  } catch (e) {
    // localStorage unavailable (private mode, quota, etc.) — play on, just don't persist.
  }
}

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(record));
  } catch (e) {
    // Same as above — non-fatal.
  }
}

/** Call when the player wins a round (not necessarily the match). */
export function recordRoundWin() {
  record.wins++;
  save();
}

/** Call when the player loses a round (not necessarily the match). */
export function recordRoundLoss() {
  record.losses++;
  save();
}

/** Call when the player wins the whole match (becomes champion). */
export function recordChampionship() {
  record.championships++;
  save();
}

load();

export const contract = {
  does: "Persists the player's win/loss/championship record across reloads via localStorage.",
  owns: "The record{wins,losses,championships} object and its localStorage key.",
  needs: "window.localStorage (guarded, non-fatal if absent).",
  inputs: "recordRoundWin()/recordRoundLoss()/recordChampionship() calls from scenes.js.",
  outputs: "The live `record` object, mirrored into localStorage on every change.",
  connectsTo: "scenes/scenes.js.",
  helps: "Makes progress survive a reload — the gap every earlier build in this thread left open.",
  returns: "record, load(), recordRoundWin(), recordRoundLoss(), recordChampionship().",
  starts: "load() at module evaluation, before boot renders the title screen.",
  finishes: "Never — the record accumulates for the lifetime of the install."
};
