/*
CONTRACT — sw.js (PWA / Offline Layer)
1. What does it do?        Caches the app shell — every ES module in src/ plus the sprite sheet —
                            so MOBATTLE boots and plays with no network after first load.
2. What does it own?       The CacheStorage bucket "mobattle-shell-v1" and the install/activate/fetch lifecycle.
3. What does it need?      A fixed list of shell files that exist at build time.
4. What does it input?     fetch events from the page; install/activate events from the browser.
5. What does it output?    Cached Response objects served instead of network requests when offline.
6. What does it connect to? index.html (registers this file), CacheStorage API, the browser's SW runtime.
7. What does it help?      Instant repeat loads and offline play on Android Chrome.
8. What does it return?    A Response for every fetch — cached copy first, network fallback second.
9. What does it start?     Caching of SHELL_FILES on "install"; cache cleanup on "activate".
10. What does it finish?   Stale caches from older versions are deleted on activate.
*/

const CACHE_NAME = 'mobattle-shell-v2';
const SHELL_FILES = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './assets/fighter_sheet.png',
  './src/content/spriteAtlas.js',
  './src/content/fighter.js',
  './src/core/state.js',
  './src/input/input.js',
  './src/movement/movement.js',
  './src/combat/combat.js',
  './src/ai/ai.js',
  './src/fx/fx.js',
  './src/audio/audio.js',
  './src/persist/persist.js',
  './src/ui/hud.js',
  './src/render/render.js',
  './src/scenes/scenes.js',
  './src/boot/boot.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          return response;
        })
        .catch(() => caches.match('./index.html'));
    })
  );
});
